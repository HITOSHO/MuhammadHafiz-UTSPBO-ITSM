/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class Kelulsan2 {
    public static void main(String[] args) {
    Scanner inp = new Scanner(System.in);
    
    // Ambil Nama
    System.out.print("Masukkan nama anda\t = ");
    String nama = inp.next();
    
    // Ambil NIM
    System.out.print("Masukkan jenis kelamin\t = ");
    String kelamin = inp.next();
    
    // Ambil Nilai
    System.out.print("Masukkan Tinggi badan\t = ");
    int tinggi = inp.nextInt();

    if("laki-laki".equals(kelamin)) {
        if(tinggi >= 170) {
          System.out.println("Anda Gagal");
    } else {
          System.out.println("Selamat Anda Lulus");
        }
}else if("perempuan".equals(kelamin)) {
        if (tinggi >= 160) {
          System.out.println("Anda Gagal");
    } else {
          System.out.println("Selamat Anda Lulus");
       }
     }
    }
}   


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class Kelulusan1 {
   public static void main(String[] args) {
       //Buat Scanner
       Scanner inp = new Scanner (System.in);
       
       //Ambil nama
       System.out.println("Masukkan nama anda = ");
       String Nama = inp.next();
       
       //Amnil NIM
       System.out.println("Masukkan NIM = ");
       String NIM = inp.next();
       
       //Ambil Nilai
       System.out.println("Masukkan Nilai = ");
       int nilai = inp.nextInt();
       
       //Print
       if (nilai > 60) {
           System.out.println("Anda lulus");
       }else {
           System.out.println("Anda tidak lulus");
       }
   } 
}

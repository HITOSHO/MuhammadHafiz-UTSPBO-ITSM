
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class InputKeyboardBIO {
    public static void main(String[] args){
        Scanner inputan = new Scanner(System.in);
        
        String Nama, 
        Nim, 
        Alamat, 
        Kelas;
        
        System.out.print("Masukkan Nama     :");
        Nama = inputan.nextLine();
        
        System.out.print("Masukkan Nim      :");
        Nim = inputan.nextLine();
        
        System.out.print("Masukkan Alamat   :");
        Alamat = inputan.nextLine();
        
        System.out.println();
        
        System.out.println("-----Hasil-----");
        System.out.println("Nama        :       "+ Nama);
        System.out.println("Nim         :       "+ Nim);
        System.out.println("Alamat      :       "+ Alamat);
        
    }
}


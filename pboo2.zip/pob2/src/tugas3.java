
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class tugas3 {
     public static void main(String[] args){
         Scanner inputan = new Scanner (System.in);
         
         String Nama,
         Nim,
         Semester,
         Kelas;
         
         System.out.print("Masukan Nama     :");
         Nama = inputan.nextLine();
         
         System.out.print("Masukan Nim      :");
         Nim = inputan.nextLine();
         
         System.out.print("Masukan Semester :");
         Semester = inputan.nextLine();
         
         System.out.print("Masukan Kelas    :");
         Kelas = inputan.nextLine();
     }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Latihan1 {
    public static void main(String[] args) {
        int angka = 100;
        if (angka < 150){
            System.out.println("Ini merupakan statment if");
        }
        System.out.println("Program selesa");
    }
}

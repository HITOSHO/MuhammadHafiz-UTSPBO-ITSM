
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Latihan05 {
    public static void main(String [] args){
        Scanner X = new Scanner(System.in).useDelimiter("\n");
        System.out.print("Masukkan nilai huruf untuk rata rata : ");
        int a = X.nextInt();
                if (a>=100){
           System.out.println("Nilai Anda E");
          }
          else if (a>=0&&a<=45){
           System.out.println("Nilai Anda E");
          }
          else if (a>=45&&a<=54){
           System.out.println("Nilai Anda D");
          }
          else if (a>=55&&a<=64){
           System.out.println("Nilai Anda C");
          }
          else if (a>=65&&a<=79){
           System.out.println("Nilai Anda B");
          }
          else if (a>=80&&a<=100){
           System.out.println("Nilai Anda A");
        }
     }
 }

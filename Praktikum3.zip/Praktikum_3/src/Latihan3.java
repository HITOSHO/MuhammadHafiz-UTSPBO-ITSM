/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class Latihan3 {
     public static void main(String[] args) {
         String jawaban, jawaban1;
         Scanner scan = new Scanner(System.in).useDelimiter("\n");
         System.out.println("Apakah anda mahasiswa ? ");
         jawaban = scan.next();
         if(("iya".equals(jawaban))||("IYA".equals(jawaban))){
             System.out.println("Apakah anda selallu terlambat masuuk kelas?");
             jawaban1 = scan.next();
             if (("tidak".equals(jawaban1)) ||("TIDAK".equals(jawaban1))){
                System.out.println("Bagus, Pertahankan!!!");
                
         }
         }
     }
}


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Latihan06 {
    public static void main(String [] args){
 
        Scanner input = new Scanner(System.in);
        System.out.println("Urutan Zodiac ke- = ");
        int Zodiak = input.nextInt();
        System.out.println("");
        
        switch (Zodiak){
            case 1:
                System.out.println("Urutan Zodiak ke-" + Zodiak + " adalah Aquarius");
                break;
            case 2:
                System.out.println("Urutan Zodiak ke-" + Zodiak + " adalah Pisces");
                break;
            case 3:
                System.out.println("Urutan Zodiak ke-" + Zodiak + " adalah Aries");
                break;
            case 4:
                System.out.println("Urutan Zodiak ke-" + Zodiak + " adalah Taurus");
                break;
            case 5:
                System.out.println("Urutan Zodiak ke-" + Zodiak + " adalah Gemini");
                break;
            case 6:
                System.out.println("Urutan Zodiak ke-" + Zodiak+ " adalah Cancer");
                break;
            case 7:
                System.out.println("Urutan Zodiak Ke-" + Zodiak+ " adalah Leo");
                break;
            case 8:
                System.out.println("Urutan Zodiak Ke-" + Zodiak+ " adalah Virgo");
                break;
            case 9:
                System.out.println("Urutan Zodiak Ke-" + Zodiak+ " adalah Libra");
                break;
            case 10:
                System.out.println("Urutan Zodiak Ke-" + Zodiak+ " adalah Scorpio");
                break;
            case 11:
                System.out.println("Urutan Zodiak Ke-" + Zodiak+ " adalah Sagittarius");
                break;
            case 12:
                System.out.println("Urutan Zodiak Ke-" + Zodiak+ " adalah Capricon");
                break;
            default:
                System.out.println("Tidak ada Zodiak ke-" + Zodiak);
        }
    }
}


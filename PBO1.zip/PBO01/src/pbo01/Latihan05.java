/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo01;

/**
 *
 * @author ASUS
 */

import java.util.Scanner;

public class Latihan05 {
    public static void main(String[] args){
        String nama;
        Scanner inputan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Masukan Nama Lengkap Anda :");
        nama = inputan.next();
        System.out.println("Halo... "+nama+",Selamat Belajar Java");
        
    }
}

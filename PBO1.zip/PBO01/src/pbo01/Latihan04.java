/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo01;

/**
 *
 * @author ASUS
 */
public class Latihan04 {
    public static void main(String[]args){
        String sistem_Operasi ="Windows 10", versi = "64 bit", pemilik ="Muhammad Hafiz";
        
        
        System.out.println("Sistem Operasi ="+sistem_Operasi);
        System.out.println("Versi ="+versi);
        System.out.println("Pemilik ="+pemilik);
    }
}

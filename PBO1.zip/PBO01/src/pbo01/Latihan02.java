/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo01;

/**
 *
 * @author ASUS
 */
public class Latihan02 {
    public static void main(String[] args){
        System.out.println("Ini Cuman Print");
        
        
        System.out.println("Ini Cuman Println");
        System.out.println("1 2 3");
        System.out.println("");
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
    }
}
 
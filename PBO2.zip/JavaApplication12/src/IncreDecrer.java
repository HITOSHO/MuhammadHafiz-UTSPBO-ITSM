/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class IncreDecrer {
     public static void main(String[] args) {
        int a = 0; 
        int b = 0; 
        int c = 9; 
        int d = 9;
        // Print ke 1 
        System.out.println("Print ke 1"); 
        System.out.println("A = " + a++); 
        System.out.println("B = " + ++b); 
        System.out.println("C = " + c--); 
        System.out.println("D = " + --d);
        // Print ke 2 
        System.out.println("Print ke 2");
        System.out.println("A = " + a++);
        System.out.println("B = " + ++b);
        System.out.println("C = " + c--);
        System.out.println("D = " + --d);
        // Print ke 3 
        System.out.println("Print ke 3");
        System.out.println("A = " + a++);
        System.out.println("B = " + ++b);
        System.out.println("C = " + c--);
        System.out.println("D = " + --d);
        // Print ke 4 
        System.out.println("Print ke 4");  
        System.out.println("A = " + a++);  
        System.out.println("B = " + ++b);  
        System.out.println("C = " + c--);  
        System.out.println("D = " + --d);
     }    
}

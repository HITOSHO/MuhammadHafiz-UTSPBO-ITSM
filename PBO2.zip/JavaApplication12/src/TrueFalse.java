/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class TrueFalse {
    public static void main(String[] args){
        String nama = "HYABUSA";
        int nilai = 544;
        
        boolean lulus = false;
        System.out.println("Nama :"+nama);
        System.out.println("Nilai :"+nilai);
        System.out.println("Status :"+lulus);
        
    }
}
